BOOTSTRAP MODAL MESSAGES
------------------------
Transform Drupal messages into Bootstrap Modals!


CONFIGURATION
-------------
For many use cases, the default settings will be enough.  Turn it on = done.
I am a huge fan of 0-config, too many things to configure in Drupal already.
That said, there are plenty of configuration options at:
/admin/config/user-interface/bootstrap_modal_messages


GOOD TO KNOW
------------
Built for Bootstrap 3.
This module does not attempt in any way to figure out if you have Bootstrap.


AUTHOR INFO
-----------
Joshua Walker 'drastik'
http://drastikbydesign.com
https://drupal.org/user/433663

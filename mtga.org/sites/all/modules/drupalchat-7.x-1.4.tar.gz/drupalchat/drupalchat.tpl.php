<?php 
?>

<div id="drupalchat-wrapper">
  <div id="drupalchat">
  	<?php print $subpanels; ?>
	<div id="drupalchat-chat-options" class="drupalchat_popup">
      <ul>
      <li id="drupalchat-chat-options-s"><a href="#">Mute</a></li>
      </ul>
    </div>
  </div>
</div>
<?php

/**
 * @file
 * Implementation file for FBAutopostException class.
 */

/**
 * Type naming the ErrorException class
 */
class FBAutopostException extends ErrorException {
  // Left blank intentionally.
}

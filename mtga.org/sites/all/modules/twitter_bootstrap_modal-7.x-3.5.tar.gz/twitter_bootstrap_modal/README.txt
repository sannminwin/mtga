Twitter Bootstrap Modal

Twitter Boostrap Modal lets you load content only from any Drupal URL or specific function on a Twitter Bootstrap Modal.

This module relies on Twitter Bootstrap Modal functionality, so you need to load Twitter Boostrap libraries with at least modals included.

AJAX functionality is handled by jQuery AJAX load module.
Instalation:

    Download an enable jQuery AJAX load module.
    Download and enable this module.
    Add Twitter Bootstrap libraries either by using a Bootstrap theme or adding libraries by your own.
    Set jQuery classes to trigger modal.
    Add trigger classes (by default .jquery_ajax_load_TB) to links you want to enable as modal trigger.


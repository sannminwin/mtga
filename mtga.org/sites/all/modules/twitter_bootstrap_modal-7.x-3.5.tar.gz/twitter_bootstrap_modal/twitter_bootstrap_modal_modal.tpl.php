<?php
/**
 * @file
 * Template file for the theming the modal box.
 *
 * Available custom variables:
 * - $site_name
 * - $render_string
 *
 */
?>

  <?php  print $render_string; ?>
